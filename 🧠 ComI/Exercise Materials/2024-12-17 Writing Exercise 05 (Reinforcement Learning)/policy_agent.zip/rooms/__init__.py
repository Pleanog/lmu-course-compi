import gymnasium as gym
from gymnasium.envs.registration import register

rooms9 = [  '# # # # # # # # #',
            '# . . . # . . . #',
            '# . . . # . . . #',
            '# . . . . . . . #',
            '# . . . # # . # #',
            '# . # # # . . . #',
            '# . . . # . . . #',
            '# . . . . . . . #',
            '# # # # # # # # #'  ]

rooms11 = [ '# # # # # # # # # # #',
            '# . . . . # . . . . #',
            '# . . . . # . . . . #',
            '# . . . . . . . . . #',
            '# . . . . # . . . . #',
            '# # . # # # . . . . #',
            '# . . . . # # # # . #',
            '# . . . . # . . . . #',
            '# . . . . # . . . . #',
            '# . . . . # . . . . #',
            '# # # # # # # # # # #' ]

rooms13 = [ '# # # # # # # # # # # # #',
            '# . . . . . # . . . . . #',
            '# . . . . . # . . . . . #',
            '# . . . . . . . . . . . #',
            '# . . . . . # . . . . . #',
            '# . . . . . # . . . . . #',
            '# # . # # # # . . . . . #',
            '# . . . . . # # # . # # #',
            '# . . . . . # . . . . . #',
            '# . . . . . # . . . . . #',
            '# . . . . . . . . . . . #',
            '# . . . . . # . . . . . #',
            '# # # # # # # # # # # # #' ]

rooms17 = [ '# # # # # # # # # # # # # # # # #',
            '# . . . . . . . # . . . . . . . #',
            '# . . . . . . . # . . . . . . . #',
            '# . . . . . . . . . . . . . . . #',
            '# . . . . . . . # . . . . . . . #',
            '# . . . . . . . # . . . . . . . #',
            '# . . . . . . . # . . . . . . . #',
            '# . . . . . . . # . . . . . . . #',
            '# # . # # # # # # . . . . . . . #',
            '# . . . . . . . # . . . . . . . #',
            '# . . . . . . . # # # # . # # # #',
            '# . . . . . . . # . . . . . . . #',
            '# . . . . . . . . . . . . . . . #',
            '# . . . . . . . # . . . . . . . #',
            '# . . . . . . . # . . . . . . . #',
            '# . . . . . . . # . . . . . . . #',
            '# # # # # # # # # # # # # # # # #' ]

rooms25 = [ '# # # # # # # # # # # # # # # # # # # # # # # # #',
            '# . . . . . # . . . . . . . . . . . # . . . . . #',
            '# . . . . . # . . . . . # . . . . . # . . . . . #',
            '# . . . . . # . . . . . # . . . . . # . . . . . #',
            '# . . . . . . . . . . . # . . . . . # . . . . . #',
            '# . . . . . # . . . . . # . . . . . . . . . . . #',
            '# . # # # # # . . . . . # # # # # . # . . . . . #',
            '# . . . . . # # # # . # # . . . . . # # . # # # #',
            '# . . . . . # . . . . . . . . . . . # . . . . . #',
            '# . . . . . # . . . . . # . . . . . # . . . . . #',
            '# . . . . . # . . . . . # . . . . . # . . . . . #',
            '# . . . . . . . . . . . # . . . . . . . . . . . #',
            '# # # # # # # # # # # # # # # # # # # # # # # # #' ]

register( id="rooms9-fixed", entry_point="rooms.rooms:RoomsEnv", 
          kwargs={'max_steps': 50, 'layout': rooms9, 'initial_positions': [[1, 1], [7, 7]],})
register( id="rooms9-random", entry_point="rooms.rooms:RoomsEnv", kwargs={'max_steps': 500, 'layout': rooms9})

register( id="rooms11-fixed", entry_point="rooms.rooms:RoomsEnv", 
          kwargs={'max_steps': 100, 'layout': rooms11, 'initial_positions': [[1, 1], [9, 9]],})
register( id="rooms11-random", entry_point="rooms.rooms:RoomsEnv", kwargs={'max_steps': 100, 'layout': rooms11})

register( id="rooms13-fixed", entry_point="rooms.rooms:RoomsEnv", 
          kwargs={'max_steps': 150, 'layout': rooms13, 'initial_positions': [[1, 1], [11, 11]],})
register( id="rooms13-random", entry_point="rooms.rooms:RoomsEnv", kwargs={'max_steps': 150, 'layout': rooms13})

register( id="rooms17-fixed", entry_point="rooms.rooms:RoomsEnv", 
          kwargs={'max_steps': 200, 'layout': rooms17, 'initial_positions': [[1, 1], [15, 15]],})
register( id="rooms17-random", entry_point="rooms.rooms:RoomsEnv", kwargs={'max_steps': 200, 'layout': rooms17})

register( id="rooms25-fixed", entry_point="rooms.rooms:RoomsEnv", 
          kwargs={'max_steps': 250, 'layout': rooms25, 'initial_positions': [[1, 1], [23, 11]],})
register( id="rooms25-random", entry_point="rooms.rooms:RoomsEnv", kwargs={'max_steps': 250, 'layout': rooms25})
