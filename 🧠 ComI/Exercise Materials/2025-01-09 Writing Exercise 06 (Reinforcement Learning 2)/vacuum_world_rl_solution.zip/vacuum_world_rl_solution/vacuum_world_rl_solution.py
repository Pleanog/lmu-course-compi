import pygame
import random
from collections import namedtuple
from enum import Enum

# Screen dimensions
SCREEN_WIDTH = 1200
SCREEN_HEIGHT = 400

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Load and resize sprites
ROBOT_IMG = pygame.transform.scale(pygame.image.load('robot_sprite.png'), (100,75))
DIRT_IMG = pygame.transform.scale(pygame.image.load('dirt_sprite.png'),(100,100))

def render_rooms(screen, N, font, screen_width, screen_height, padding=10, stroke_width=5):
    rooms = []
    room_width = (screen_width - (N + 1) * padding) // N
    room_height = screen_height - 2*padding
    y = padding
    for i in range(N):
        x = padding + i * (room_width + padding)
        rect = pygame.Rect(x, y, room_width, room_height)
        pygame.draw.rect(screen, BLACK, rect, stroke_width)
        
        label = font.render(str(i), True, BLACK)
        label_rect = label.get_rect(center=(x + room_width // 2, y + 20))
        screen.blit(label, label_rect)
        
        rooms.append(rect)
    return rooms


def get_robot_position(n, rooms):
    return (rooms[n].centerx - ROBOT_IMG.get_width() // 2,
            rooms[n].centery - ROBOT_IMG.get_height() // 2)

def get_dirt_position(n, rooms):
    return (rooms[n].centerx - DIRT_IMG.get_width() // 2,
            rooms[n].centery + 100 - DIRT_IMG.get_height() // 2)

def gets_dirty(p=0.5):
    return p <= random.random()

class VacuumWorld:
    def __init__(self, n_rooms:int=10, max_steps:int=50):
        self.n_rooms = n_rooms
        self.max_steps = max_steps
        self.robot_position = 0
        self.room_dirty = [0] * self.n_rooms
        self.steps = 0

        # Start pygame
        pygame.init()
        # Set label font
        self.font = pygame.font.SysFont(None, 48)

        # Screen setup
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption(f'CoIn - {self.n_rooms}-Room Vacuum World')
        self.clock = pygame.time.Clock()

    def reset(self):
        self.steps = 0
        self.robot_position = 0
        self.room_dirty = [float(gets_dirty()) for _ in range(self.n_rooms)]
        return [float(self.robot_position), *self.room_dirty], None # Observation

    def step(self, action):
        self.steps += 1
        # actions:
        # 0: move left
        # 1: vacuum
        # 2: move right
        if (action == 0) and (self.robot_position > 1):
            self.robot_position -= 1
        
        if (action == 2) and (self.robot_position < self.n_rooms - 1):
            self.robot_position += 1

        reward = 0
        was_dirty = bool(self.room_dirty[self.robot_position])
        if action == 1:
            self.room_dirty[self.robot_position] = 0
            if was_dirty:
                reward += 10
            else:
                reward -= 1
        
        terminated = truncated = False
        if self.steps == self.max_steps:
            terminated = True
        if sum(self.room_dirty) == 0:
            terminated = True
        
        return [self.robot_position, *self.room_dirty], reward, terminated, truncated, {}

    def render(self):
        self.screen.fill(WHITE)
    
        # Render rooms and get their rectangles
        rooms = render_rooms(self.screen, self.n_rooms, self.font, SCREEN_WIDTH, SCREEN_HEIGHT)
        
        # Render a step counter
        step_label = self.font.render(f"{self.steps}", True, BLACK)
        self.screen.blit(step_label, (20, SCREEN_HEIGHT-50))

        # Draw robot
        robot_pos = get_robot_position(self.robot_position, rooms)
        self.screen.blit(ROBOT_IMG, robot_pos)
        
        # Draw dirt in respective rooms
        for i in range(self.n_rooms):
            if bool(self.room_dirty[i]):
                dirt_pos = get_dirt_position(i, rooms)
                self.screen.blit(DIRT_IMG, dirt_pos)
        
        pygame.display.flip()
        timeout_in_ms = 100
        self.clock.tick(1000/timeout_in_ms)

    def close(self):
        pygame.quit()


if __name__=="__main__":
    
    # Example application with our random policy
    def random_robot_policy(observation):
        return random.choice([0,1,2])

    env = VacuumWorld(10, 500)
    obs, _ = env.reset()
    done = False
    undiscounted_return = 0
    while not done:
        action = random_robot_policy(obs)
        next_obs, reward, terminated, truncated, _ = env.step(action)
        done = terminated or truncated
        undiscounted_return += reward
        obs = next_obs
        env.render()
    print(f"reached return: {undiscounted_return}")
    env.close()