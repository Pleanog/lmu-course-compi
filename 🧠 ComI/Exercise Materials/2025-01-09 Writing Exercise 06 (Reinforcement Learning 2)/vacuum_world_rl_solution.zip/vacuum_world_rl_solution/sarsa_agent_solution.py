import random
import numpy

def epsilon_greedy(q_values, epsilon=0.1):
    if numpy.random.rand() <= epsilon:
        return random.choice(range(len(q_values)))
    else:
        return numpy.argmax(q_values)


class Agent:
    """ Base class of an autonomously acting and learning agent. """

    def __init__(self, params):
        self.nr_actions = params["nr_actions"]

    def policy(self, state):
        """ Behavioral strategy of the agent. Maps states to actions. """
        pass

    def update(self, state, action, reward, next_state, done):
        """ Learning method of the agent. Integrates experience into the agent's current knowledge. """
        pass
        

class RandomAgent(Agent):
    """ Randomly acting agent. """

    def __init__(self, params):
        super(RandomAgent, self).__init__(params)
        
    def policy(self, state):
        return random.choice(range(self.nr_actions))


class SARSALearner(Agent):
    """ Autonomous agent using SARSA. """

    def __init__(self, params):
        super(SARSALearner, self).__init__(params)
        self.gamma = params["gamma"]
        self.alpha = params["alpha"]
        self.epsilon = params["epsilon"]
        self.epsilon_decay = params["epsilon_decay"]
        self.epsilon_min = params["epsilon_min"]
        self.q_values = dict()
        self.env = params["env"]
        
    def q_table(self, state):
        if not isinstance(state, numpy.ndarray):
            state = numpy.array(state)
            
        state = numpy.array2string(state)
        if state not in self.q_values:
            self.q_values[state] = numpy.zeros(self.nr_actions)
        return self.q_values[state]

    def policy(self, state):
        q_values = self.q_table(state)
        return epsilon_greedy(q_values, epsilon=self.epsilon)

    def update(self, state, action, reward, next_state, done):

        current_q = self.q_table(state)[action]
        td_target = reward
        next_action = self.policy(next_state)
        if not done:
            td_target += self.gamma * self.q_table(next_state)[next_action]
        td_error = td_target - current_q
        self.q_table(state)[action] = current_q + self.alpha * td_error

        self.epsilon = max(self.epsilon_min, self.epsilon - self.epsilon_decay)

    def run(self, state, train, render, all_rewards):
        rewards = []
        discounted_return = 0
        done = False
        time_step = 0
        while not done:
            # 1. Select action according to policy
            action = self.policy(state)
            
            # 2. Execute selected action
            next_state, reward, terminated, truncated, _ = self.env.step(action)
            done = terminated or truncated
            discounted_return += reward * (self.gamma ** time_step)
            if train:
            # 3. Integrate new experience into agent
                self.update(state, action, reward, next_state, done)
            rewards.append(reward)
            if done:
                all_rewards.append(numpy.sum(rewards))
                break
            state = next_state
            time_step += 1
            if render:
                self.env.render()

        return discounted_return        