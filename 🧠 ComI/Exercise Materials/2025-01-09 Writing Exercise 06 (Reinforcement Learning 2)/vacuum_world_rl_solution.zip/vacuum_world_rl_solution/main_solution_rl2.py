from vacuum_world_rl_solution import VacuumWorld
import gymnasium as gym
import matplotlib.pyplot as plot
from agent_solution import RandomAgent, PolAgent
import numpy as np
from sarsa_agent_solution import SARSALearner

# Setup with:
#> pip install gymnasium matplotlib torch pygame

def run_episode(environment, agent, nr_episode, all_rewards, render=False, train=False):
    state, _ = environment.reset()
    if render:
        environment.render()
    episode_reward = agent.run(state, train, render, all_rewards)
    if nr_episode % 100 == 0:
        print(nr_episode, ":", episode_reward)
    return episode_reward

n_rooms = 10
env = VacuumWorld(n_rooms, 50) # (adapt nr-steps as needed, more might be needed!)

params = dict()
params["nr_actions"] = 3 #actions (0: move left, 1:vacuum, 2: move right)
params["obs_space"] = 1 + n_rooms #observation: agent position + dirty 0/1 for all rooms
params["alpha"] = 0.01  # learning rate
params["gamma"] = 0.99  # discount factor
params["epsilon"] = 0.75  # exploration rate (at the start of learning)
params["epsilon_min"] = 0.01  # minimal exploration rate
params["epsilon_decay"] = 0.0001  # epsilon decay
params["training_episodes"] = 2500  # training duration
params["demonstration_episodes"] = 2  # demonstration duration
params["render"] = True
params["env"] = env

ag = RandomAgent(params)
#ag = PolAgent(params)
#ag = SARSALearner(params)

all_rewards = []

# train the agent
training_results = [run_episode(env, ag, ep, all_rewards, render=False, train=True) for ep in range(params["training_episodes"])]

# Plot episode reward
x = range(params["training_episodes"])
y = training_results
plot.plot(x, y)
plot.title("training progress")
plot.xlabel("episode")
plot.ylabel("episode reward")
plot.show()


# Mean over every 10 episodes
w_size = 10
x = range(0, len(training_results), w_size)
y = [np.mean(training_results[i:i + w_size]) for i in range(0, len(training_results), w_size)]
plot.plot(x, y)
plot.title('training progress')
plot.xlabel('episode')
plot.ylabel('mean reward (Over 10 Episodes)')
plot.show()

# let the agent demonstrate the learned policy
for ep in range(params["demonstration_episodes"]):
    run_episode(env, ag, ep, all_rewards, render=True, train=False)

